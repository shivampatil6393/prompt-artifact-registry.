from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from typing import List, Optional
import datetime
import json
import random # For mock generation
import os
from datetime import timedelta
from jose import JWTError, jwt
from passlib.context import CryptContext

import models, schemas, llm_services
from models import SessionLocal, engine, UserRole, PromptStatus, ArtifactStatus


try:
    models.Base.metadata.create_all(bind=engine)
except Exception as e:
    print(f"Error creating database tables: {e}")


app = FastAPI(title="Prompt & Artifact Registry", root_path="/api")

# --- Security Config ---
SECRET_KEY = os.getenv("SECRET_KEY")
if not SECRET_KEY:
    if os.getenv("VERCEL") or os.getenv("POSTGRES_URL") or os.getenv("DATABASE_URL"):
        raise RuntimeError("SECRET_KEY must be configured for deployment")
    SECRET_KEY = "local-development-only-change-before-deployment"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 300

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/token")


# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/health")
def health_check(db: Session = Depends(get_db)):
    status_data = {
        "status": "ok",
        "database": "unknown",
        "bcrypt_version": "unknown",
        "env_vars": {
            "POSTGRES_URL_SET": bool(os.getenv("POSTGRES_URL")),
            "DATABASE_URL_SET": bool(os.getenv("DATABASE_URL")),
            "SECRET_KEY_SET": bool(os.getenv("SECRET_KEY"))
        }
    }
    
    # Check Database
    try:
        from sqlalchemy import text
        db.execute(text("SELECT 1"))
        status_data["database"] = "connected"
    except Exception as e:
        status_data["database"] = f"failed: {str(e)}"
        status_data["status"] = "error"

    # Check Bcrypt
    try:
        import bcrypt
        status_data["bcrypt_version"] = bcrypt.__version__
    except ImportError:
        status_data["bcrypt_version"] = "missing"
    except Exception as e:
        status_data["bcrypt_version"] = f"error: {str(e)}"

    return status_data


# --- Auth (Real) ---

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.datetime.utcnow() + expires_delta
    else:
        expire = datetime.datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = schemas.TokenData(username=username)
    except JWTError:
        raise credentials_exception
    user = db.query(models.User).filter(models.User.username == token_data.username).first()
    if user is None:
        raise credentials_exception
    return user

@app.post("/auth/signup", response_model=schemas.User)
def signup(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.username == user.username).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Username already registered")
    hashed_password = get_password_hash(user.password)
    db_user = models.User(username=user.username, hashed_password=hashed_password, role=UserRole.AUTHOR.value)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@app.post("/auth/token", response_model=schemas.Token)
def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == form_data.username).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/auth/me", response_model=schemas.User)
def read_users_me(current_user: models.User = Depends(get_current_user)):
    return current_user

# --- Prompts ---

@app.post("/prompts/", response_model=schemas.Prompt)
def create_prompt(prompt: schemas.PromptCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    # Audit log
    log = models.AuditLog(user_id=current_user.id, action="CREATE_PROMPT", details=f"Created prompt {prompt.name}")
    db.add(log)
    
    db_prompt = models.Prompt(name=prompt.name, description=prompt.description)
    db.add(db_prompt)
    db.commit()
    db.refresh(db_prompt)
    return db_prompt

@app.get("/prompts/", response_model=List[schemas.Prompt])
def list_prompts(skip: int = 0, limit: int = 100, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    return db.query(models.Prompt).offset(skip).limit(limit).all()

@app.post("/prompts/{prompt_id}/versions/", response_model=schemas.PromptVersion)
def create_prompt_version(prompt_id: int, version: schemas.PromptVersionCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    if not db.query(models.Prompt).filter(models.Prompt.id == prompt_id).first():
        raise HTTPException(status_code=404, detail="Prompt not found")
    # Get last version number
    last_version = db.query(models.PromptVersion).filter(models.PromptVersion.prompt_id == prompt_id).order_by(models.PromptVersion.version_number.desc()).first()
    new_version_num = (last_version.version_number + 1) if last_version else 1
    
    db_version = models.PromptVersion(
        prompt_id=prompt_id,
        version_number=new_version_num,
        text=version.text,
        created_by_id=current_user.id,
        status=PromptStatus.DRAFT
    )
    db.add(db_version)
    
    # Audit
    log = models.AuditLog(user_id=current_user.id, action="CREATE_PROMPT_VERSION", details=f"Created version {new_version_num} for prompt {prompt_id}")
    db.add(log)
    
    db.commit()
    db.refresh(db_version)
    return db_version

@app.get("/prompts/{prompt_id}/versions/", response_model=List[schemas.PromptVersion])
def list_prompt_versions(prompt_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    return db.query(models.PromptVersion).filter(models.PromptVersion.prompt_id == prompt_id).order_by(models.PromptVersion.version_number.desc()).all()

@app.put("/prompts/versions/{version_id}/status", response_model=schemas.PromptVersion)
def update_prompt_version_status(version_id: int, status: PromptStatus, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    version = db.query(models.PromptVersion).filter(models.PromptVersion.id == version_id).first()
    if not version:
        raise HTTPException(status_code=404, detail="Version not found")
    if current_user.role not in (UserRole.APPROVER.value, UserRole.ADMIN.value):
        raise HTTPException(status_code=403, detail="Approver or Admin role required")
    version.status = status
    
    log = models.AuditLog(user_id=current_user.id, action="UPDATE_PROMPT_STATUS", details=f"Updated version {version_id} status to {status}")
    db.add(log)
    
    db.commit()
    db.refresh(version)
    return version

# --- Artifacts ---

@app.post("/artifacts/generate", response_model=schemas.Artifact)
def generate_artifact(prompt_version_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    # 1. Fetch prompt version
    pv = db.query(models.PromptVersion).filter(models.PromptVersion.id == prompt_version_id).first()
    if not pv:
        raise HTTPException(status_code=404, detail="Prompt version not found")
    
    # 2. Call LLM Service
    llm_response = llm_services.generate_text(pv.text, model_name="gemini-flash-latest")
    
    generated_content = llm_response["content"]
    # Merge existing metadata with new LLM metadata
    metadata = {
        "timestamp": datetime.datetime.now().isoformat(),
        "prompt_length": len(pv.text),
        **llm_response.get("metadata", {})
    }
    
    # 3. Store artifact
    db_artifact = models.Artifact(
        prompt_version_id=prompt_version_id,
        content=generated_content,
        metadata_json=json.dumps(metadata),
        status=ArtifactStatus.PENDING_REVIEW
    )
    db.add(db_artifact)
    
    log = models.AuditLog(user_id=current_user.id, action="GENERATE_ARTIFACT", details=f"Generated artifact for prompt version {prompt_version_id}")
    db.add(log)
    
    db.commit()
    db.refresh(db_artifact)
    return db_artifact

@app.get("/artifacts/", response_model=List[schemas.Artifact])
def list_artifacts(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    return db.query(models.Artifact).order_by(models.Artifact.created_at.desc()).all()

@app.get("/artifacts/{artifact_id}", response_model=schemas.Artifact)
def get_artifact(artifact_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    art = db.query(models.Artifact).filter(models.Artifact.id == artifact_id).first()
    if not art:
        raise HTTPException(status_code=404, detail="Artifact not found")
    return art

# --- Approvals ---

@app.post("/artifacts/{artifact_id}/approve", response_model=schemas.Artifact)
def approve_artifact(artifact_id: int, approval: schemas.ApprovalCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    artifact = db.query(models.Artifact).filter(models.Artifact.id == artifact_id).first()
    if not artifact:
        raise HTTPException(status_code=404, detail="Artifact not found")
    
    if current_user.role not in (UserRole.REVIEWER.value, UserRole.APPROVER.value, UserRole.ADMIN.value):
        raise HTTPException(status_code=403, detail="Reviewer, Approver or Admin role required")
    if approval.action.lower() not in ("approve", "reject"):
        raise HTTPException(status_code=422, detail="Action must be Approve or Reject")
    if artifact.status != ArtifactStatus.PENDING_REVIEW.value:
        raise HTTPException(status_code=409, detail="Artifact has already been reviewed")
    # Create approval log
    log = models.ApprovalLog(
        artifact_id=artifact_id,
        user_id=current_user.id,
        action=approval.action,
        comment=approval.comment
    )
    db.add(log)
    
    # Update artifact status based on action
    # Logic: Reviewer approves -> Pending Approval (from Approver)? Or just straight to Approved?
    # Simple workflow: 
    # If action == "Approve", status = APPROVED (Assuming user has rights, simpler for MVP)
    # If action == "Reject", status = REJECTED
    
    if approval.action.lower() == "approve":
        artifact.status = ArtifactStatus.APPROVED
    elif approval.action.lower() == "reject":
        artifact.status = ArtifactStatus.REJECTED
        
    db.add(models.AuditLog(user_id=current_user.id, action="REVIEW_ARTIFACT", details=f"{approval.action} artifact {artifact_id}"))
    db.commit()
    db.refresh(artifact)
    return artifact

@app.get("/approvals/history/{artifact_id}", response_model=List[schemas.ApprovalLog])
def get_approval_history(artifact_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    return db.query(models.ApprovalLog).filter(models.ApprovalLog.artifact_id == artifact_id).all()

# --- Lineage ---

@app.get("/lineage/{artifact_id}", response_model=schemas.LineageResponse)
def get_lineage(artifact_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    artifact = db.query(models.Artifact).filter(models.Artifact.id == artifact_id).first()
    if not artifact:
        raise HTTPException(status_code=404, detail="Artifact not found")
    
    prompt_version = artifact.prompt_version
    prompt = prompt_version.prompt
    
    return {
        "artifact": artifact,
        "prompt_version": prompt_version,
        "prompt": prompt
    }

# --- Users ---
@app.get("/users/", response_model=List[schemas.User])
def list_users(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    if current_user.role != UserRole.ADMIN.value:
        raise HTTPException(status_code=403, detail="Admin role required")
    return db.query(models.User).all()
