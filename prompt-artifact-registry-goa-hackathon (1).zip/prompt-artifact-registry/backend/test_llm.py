
import llm_services
import sys

print("Testing LLM generation with 'gemini-flash-latest'...")
try:
    # prompt, model_name
    result = llm_services.generate_text("Say 'API Key Working' if you hear me.", model_name="gemini-flash-latest")
    print("Content:", result["content"])
    print("Metadata:", result["metadata"])
    
    if "error" in result["metadata"] or "MOCK FALLBACK" in result["content"]:
        print("Test FAILED or hit MOCK fallback")
        sys.exit(1)
    else:
        print("Test PASSED")
        sys.exit(0)
except Exception as e:
    print(f"Test crashed: {e}")
    sys.exit(1)
