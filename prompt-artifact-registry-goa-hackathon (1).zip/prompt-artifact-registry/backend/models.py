from sqlalchemy import create_engine, Column, Integer, String, Text, ForeignKey, DateTime, Enum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import enum

import os


# Database Connection Logic
# Vercel Postgres uses "POSTGRES_URL" or "DATABASE_URL"
DATABASE_URL = os.getenv("POSTGRES_URL") or os.getenv("DATABASE_URL")


if DATABASE_URL:
    if DATABASE_URL.startswith("postgres://"):
        DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)
    
    # Remove 'supa' parameter which breaks psycopg2
    try:
        import urllib.parse
        url_parts = urllib.parse.urlparse(DATABASE_URL)
        qs = urllib.parse.parse_qs(url_parts.query)
        
        changed = False
        if 'supa' in qs:
            del qs['supa']
            changed = True
        
        if changed:
            new_query = urllib.parse.urlencode(qs, doseq=True)
            DATABASE_URL = urllib.parse.urlunparse((
                url_parts.scheme,
                url_parts.netloc,
                url_parts.path,
                url_parts.params,
                new_query,
                url_parts.fragment
            ))
    except Exception as e:
        print(f"Error sanitizing connection string: {e}")


if not DATABASE_URL:
    # Fallback to SQLite for local development
    DATABASE_URL = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'prompt_registry.db')}"
    connect_args = {"check_same_thread": False}
else:
    connect_args = {}

engine = create_engine(
    DATABASE_URL, connect_args=connect_args
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

# Enums
class UserRole(str, enum.Enum):
    AUTHOR = "Author"
    REVIEWER = "Reviewer"
    APPROVER = "Approver"
    ADMIN = "Admin"

class PromptStatus(str, enum.Enum):
    DRAFT = "Draft"
    APPROVED = "Approved"
    DEPRECATED = "Deprecated"

class ArtifactStatus(str, enum.Enum):
    PENDING_REVIEW = "Pending Review"
    APPROVED = "Approved"
    REJECTED = "Rejected"

# Models
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    role = Column(String) # Stored as string, validated against UserRole

class Prompt(Base):
    __tablename__ = "prompts"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    description = Column(String)
    
    
    versions = relationship("PromptVersion", back_populates="prompt")

class PromptVersion(Base):
    __tablename__ = "prompt_versions"
    id = Column(Integer, primary_key=True, index=True)
    prompt_id = Column(Integer, ForeignKey("prompts.id"))
    version_number = Column(Integer)
    text = Column(Text)
    status = Column(String, default=PromptStatus.DRAFT)
    created_at = Column(DateTime, default=datetime.utcnow)
    created_by_id = Column(Integer, ForeignKey("users.id"))
    
    prompt = relationship("Prompt", back_populates="versions")
    created_by = relationship("User")
    artifacts = relationship("Artifact", back_populates="prompt_version")

class Artifact(Base):
    __tablename__ = "artifacts"
    id = Column(Integer, primary_key=True, index=True)
    prompt_version_id = Column(Integer, ForeignKey("prompt_versions.id"))
    content = Column(Text)
    metadata_json = Column(Text) # JSON string for model, timestamp, etc.
    status = Column(String, default=ArtifactStatus.PENDING_REVIEW)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    prompt_version = relationship("PromptVersion", back_populates="artifacts")
    approvals = relationship("ApprovalLog", back_populates="artifact")

class ApprovalLog(Base):
    __tablename__ = "approvals"
    id = Column(Integer, primary_key=True, index=True)
    artifact_id = Column(Integer, ForeignKey("artifacts.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    action = Column(String) # Approve, Reject
    comment = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    artifact = relationship("Artifact", back_populates="approvals")
    user = relationship("User")

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    action = Column(String)
    details = Column(String)
    timestamp = Column(DateTime, default=datetime.utcnow)

def init_db():
    Base.metadata.create_all(bind=engine)
