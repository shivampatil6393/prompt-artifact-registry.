
import os
import requests
import json
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")

def generate_text(prompt: str, model_name: str = "gemini-1.5-flash") -> dict:
    """
    Generates text using the Gemini REST API (lightweight, no grpcio).
    """
    if not API_KEY:
        return {
            "content": f"[MOCK] Gemini API Key missing. Mock response for: {prompt[:50]}...",
            "metadata": {"model": "mock-fallback", "error": "Missing API Key"}
        }

    # API Endpoint
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={API_KEY}"
    
    headers = {
        "Content-Type": "application/json"
    }
    
    data = {
        "contents": [{
            "parts": [{"text": prompt}]
        }]
    }

    try:
        response = requests.post(url, headers=headers, json=data, timeout=30)
        
        if response.status_code == 200:
            result = response.json()
            try:
                # Extract text from response structure
                content = result['candidates'][0]['content']['parts'][0]['text']
                return {
                    "content": content,
                    "metadata": {
                        "model": model_name,
                        "finish_reason": result['candidates'][0].get('finishReason', 'unknown')
                    }
                }
            except (KeyError, IndexError):
                return {
                    "content": "Error parsing Gemini response structure.",
                    "metadata": {"model": model_name, "error": "Unexpected model response"}
                }
                
        elif response.status_code == 429:
             return {
                "content": f"[MOCK FALLBACK] Quota exceeded (429). Simulated response for: '{prompt}'",
                "metadata": {"model": "mock-fallback", "error": "429 Quota Exceeded"}
            }
        else:
            return {
                "content": f"[GENERATION FAILED] Gemini returned HTTP {response.status_code}",
                "metadata": {"model": model_name, "error": f"HTTP {response.status_code}"}
            }

    except Exception as e:
        return {
            "content": "[GENERATION FAILED] Unable to reach Gemini",
            "metadata": {"model": model_name, "error": "Gemini connection failure"}
        }
