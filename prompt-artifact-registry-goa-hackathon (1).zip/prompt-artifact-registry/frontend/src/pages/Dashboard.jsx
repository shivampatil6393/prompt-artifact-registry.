import React, { useState, useEffect } from 'react';
import { Layers, FileText, CheckCircle, Clock } from 'lucide-react';
import api from '../api';

const StatCard = ({ title, value, icon: Icon, color }) => (
    <div className="bg-white overflow-hidden shadow rounded-lg">
        <div className="p-5">
            <div className="flex items-center">
                <div className="flex-shrink-0">
                    <Icon className={`h-6 w-6 text-${color}-600`} aria-hidden="true" />
                </div>
                <div className="ml-5 w-0 flex-1">
                    <dl>
                        <dt className="text-sm font-medium text-gray-500 truncate">{title}</dt>
                        <dd>
                            <div className="text-lg font-medium text-gray-900">{value}</div>
                        </dd>
                    </dl>
                </div>
            </div>
        </div>
    </div>
);

const Dashboard = () => {
    const [prompts, setPrompts] = useState([]);
    const [artifacts, setArtifacts] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [promptsRes, artifactsRes] = await Promise.all([
                    api.get('/prompts/'),
                    api.get('/artifacts/')
                ]);
                setPrompts(promptsRes.data);
                setArtifacts(artifactsRes.data);
            } catch (error) {
                console.error("Error fetching dashboard data", error);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    if (loading) return <div>Loading dashboard...</div>;

    const pendingApprovals = artifacts.filter(a => a.status === 'Pending Review').length;
    const approvedArtifacts = artifacts.filter(a => a.status === 'Approved').length;

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>

            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                <StatCard title="Total Prompts" value={prompts.length} icon={FileText} color="blue" />
                <StatCard title="Total Artifacts" value={artifacts.length} icon={Layers} color="indigo" />
                <StatCard title="Pending Review" value={pendingApprovals} icon={Clock} color="yellow" />
                <StatCard title="Approved Artifacts" value={approvedArtifacts} icon={CheckCircle} color="green" />
            </div>

            <div className="mt-8">
                <h2 className="text-lg font-medium text-gray-900 mb-4">Recent Activity</h2>
                <div className="bg-white shadow overflow-hidden sm:rounded-md">
                    <ul className="divide-y divide-gray-200">
                        {artifacts.slice(0, 5).map((artifact) => (
                            <li key={artifact.id} className="px-4 py-4 sm:px-6">
                                <div className="flex items-center justify-between">
                                    <div className="text-sm font-medium text-blue-600 truncate">
                                        Artifact #{artifact.id} generated
                                    </div>
                                    <div className="ml-2 flex-shrink-0 flex">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                      ${artifact.status === 'Approved' ? 'bg-green-100 text-green-800' :
                                                artifact.status === 'Rejected' ? 'bg-red-100 text-red-800' :
                                                    'bg-yellow-100 text-yellow-800'}`}>
                                            {artifact.status}
                                        </span>
                                    </div>
                                </div>
                                <div className="mt-2 sm:flex sm:justify-between">
                                    <div className="sm:flex">
                                        <p className="flex items-center text-sm text-gray-500">
                                            Prompt Version: {artifact.prompt_version_id}
                                        </p>
                                    </div>
                                    <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                                        <p>{new Date(artifact.created_at).toLocaleDateString()}</p>
                                    </div>
                                </div>
                            </li>
                        ))}
                        {artifacts.length === 0 && (
                            <li className="px-4 py-8 text-center text-gray-500">No activity yet.</li>
                        )}
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
