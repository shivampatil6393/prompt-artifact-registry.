import React, { useState, useEffect } from 'react';
import api from '../api';
import { Link } from 'react-router-dom';
import { FileText, GitBranch, CheckCircle, XCircle, Clock, History, X } from 'lucide-react'; // Added icons

const ArtifactRegistry = () => {
    const [artifacts, setArtifacts] = useState([]);
    const [statusFilter, setStatusFilter] = useState('All');
    const [historyModalId, setHistoryModalId] = useState(null);
    const [approvalHistory, setApprovalHistory] = useState([]);

    useEffect(() => {
        api.get('/artifacts/')
            .then(res => setArtifacts(res.data))
            .catch(err => console.error(err));
    }, []);

    const handleViewHistory = async (id) => {
        setHistoryModalId(id);
        try {
            const res = await api.get(`/approvals/history/${id}`);
            setApprovalHistory(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    const getStatusIcon = (status) => {
        switch (status) {
            case 'Approved': return <CheckCircle className="text-green-500" size={16} />;
            case 'Rejected': return <XCircle className="text-red-500" size={16} />;
            default: return <Clock className="text-yellow-500" size={16} />;
        }
    };

    const filteredArtifacts = artifacts.filter(a => statusFilter === 'All' || a.status === statusFilter);

    return (
        <div className="space-y-6 relative">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-gray-900">Artifact Registry</h1>
                <select
                    value={statusFilter}
                    onChange={e => setStatusFilter(e.target.value)}
                    className="border border-gray-300 rounded-md shadow-sm p-2 text-sm"
                >
                    <option value="All">All Statuses</option>
                    <option value="Pending Review">Pending Review</option>
                    <option value="Approved">Approved</option>
                    <option value="Rejected">Rejected</option>
                </select>
            </div>

            <div className="bg-white shadow overflow-hidden sm:rounded-md">
                <ul className="divide-y divide-gray-200">
                    {filteredArtifacts.map((artifact) => (
                        <li key={artifact.id} className="block hover:bg-gray-50">
                            <div className="px-4 py-4 sm:px-6">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center">
                                        <FileText className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                                        <p className="text-sm font-medium text-indigo-600 truncate">
                                            Artifact #{artifact.id}
                                        </p>
                                    </div>
                                    <div className="ml-2 flex-shrink-0 flex items-center gap-2">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                            ${artifact.status === 'Approved' ? 'bg-green-100 text-green-800' :
                                                artifact.status === 'Rejected' ? 'bg-red-100 text-red-800' :
                                                    'bg-yellow-100 text-yellow-800'}`}>
                                            {getStatusIcon(artifact.status)}
                                            <span className="ml-1">{artifact.status}</span>
                                        </span>
                                    </div>
                                </div>
                                <div className="mt-2 sm:flex sm:justify-between">
                                    <div className="sm:flex flex-col gap-2">
                                        <div className="text-sm text-gray-900 bg-gray-50 p-2 rounded border border-gray-100">
                                            {artifact.content.substring(0, 100)}...
                                        </div>
                                        <div className="flex items-center text-sm text-gray-500 mt-2">
                                            <span className="mr-4">Prompt Ver: {artifact.prompt_version_id}</span>
                                            <span>Model: {JSON.parse(artifact.metadata_json || '{}').model}</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="mt-4 flex justify-end items-center gap-4">
                                    <Link to={`/lineage/${artifact.id}`} className="flex items-center text-sm text-blue-600 hover:text-blue-900">
                                        <GitBranch size={16} className="mr-1" /> View Lineage
                                    </Link>
                                    <button onClick={() => handleViewHistory(artifact.id)} className="flex items-center text-sm text-gray-600 hover:text-gray-900">
                                        <History size={16} className="mr-1" /> History
                                    </button>
                                </div>
                            </div>
                        </li>
                    ))}
                    {filteredArtifacts.length === 0 && (
                        <div className="p-8 text-center text-gray-500">
                            No artifacts generated yet. Go to Prompts to generate one.
                        </div>
                    )}
                </ul>
            </div>

            {/* Approval History Modal */}
            {historyModalId && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                    <div className="bg-white rounded-lg max-w-lg w-full p-6 shadow-xl">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-bold">Approval History: Artifact #{historyModalId}</h3>
                            <button onClick={() => setHistoryModalId(null)} className="p-1 hover:bg-gray-100 rounded">
                                <X size={20} />
                            </button>
                        </div>
                        <div className="space-y-4 max-h-96 overflow-y-auto">
                            {approvalHistory.length > 0 ? (
                                approvalHistory.map(log => (
                                    <div key={log.id} className="border-b border-gray-100 pb-3 last:border-0">
                                        <div className="flex justify-between items-center mb-1">
                                            <span className={`px-2 py-0.5 rounded text-xs font-bold ${log.action === 'Approve' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                                {log.action.toUpperCase()}
                                            </span>
                                            <span className="text-xs text-gray-500">{new Date(log.timestamp).toLocaleString()}</span>
                                        </div>
                                        <div className="text-sm text-gray-800">{log.comment}</div>
                                        <div className="text-xs text-gray-400 mt-1">user_id: {log.user_id}</div>
                                    </div>
                                ))
                            ) : (
                                <p className="text-gray-500 text-center py-4">No approval actions recorded.</p>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ArtifactRegistry;
