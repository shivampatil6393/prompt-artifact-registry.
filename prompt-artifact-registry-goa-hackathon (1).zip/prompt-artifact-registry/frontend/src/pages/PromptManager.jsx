import React, { useState, useEffect } from 'react';
import api from '../api';
import { Plus, ChevronDown, ChevronRight, Play, GitCompare } from 'lucide-react'; // Added GitCompare
import * as Diff from 'diff';
import { useNavigate } from 'react-router-dom';

const PromptManager = () => {
    const [prompts, setPrompts] = useState([]);
    const [selectedPrompt, setSelectedPrompt] = useState(null);
    const [versions, setVersions] = useState([]);
    const [showNewPromptModal, setShowNewPromptModal] = useState(false);
    const [newPromptName, setNewPromptName] = useState('');
    const [newPromptDesc, setNewPromptDesc] = useState('');
    const [newVersionText, setNewVersionText] = useState('');
    const [showDiff, setShowDiff] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        fetchPrompts();
    }, []);

    const fetchPrompts = async () => {
        try {
            const res = await api.get('/prompts/');
            setPrompts(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    const handleSelectPrompt = async (prompt) => {
        setSelectedPrompt(prompt);
        // Load versions
        try {
            const res = await api.get(`/prompts/${prompt.id}/versions/`);
            setVersions(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    const handleCreatePrompt = async () => {
        try {
            const res = await api.post('/prompts/', { name: newPromptName, description: newPromptDesc });
            setPrompts([...prompts, res.data]);
            setShowNewPromptModal(false);
            setNewPromptName('');
            setNewPromptDesc('');
        } catch (err) {
            alert('Failed to create prompt');
        }
    };

    const handleCreateVersion = async () => {
        if (!newVersionText) return alert("Text required");
        try {
            const res = await api.post(`/prompts/${selectedPrompt.id}/versions/`, { text: newVersionText });
            setVersions([res.data, ...versions]); // Add to top
            setNewVersionText('');
        } catch (err) {
            alert('Failed to create version');
        }
    };

    const handleGenerate = async (versionId) => {
        try {
            const res = await api.post('/artifacts/generate', null, { params: { prompt_version_id: versionId } });
            alert(`Artifact generated! ID: ${res.data.id}`);
            navigate('/artifacts');
        } catch (err) {
            alert('Generation failed');
        }
    };

    return (
        <div className="h-[calc(100vh-8rem)] flex gap-6">
            {/* Sidebar List */}
            <div className="w-1/3 bg-white shadow rounded-lg flex flex-col">
                <div className="p-4 border-b border-gray-200 flex justify-between items-center">
                    <h2 className="text-lg font-semibold">Prompts</h2>
                    <button onClick={() => setShowNewPromptModal(true)} className="p-1 bg-blue-100 text-blue-600 rounded hover:bg-blue-200">
                        <Plus size={20} />
                    </button>
                </div>
                <div className="flex-1 overflow-y-auto p-2 space-y-2">
                    {prompts.map(prompt => (
                        <div
                            key={prompt.id}
                            onClick={() => handleSelectPrompt(prompt)}
                            className={`p-3 rounded cursor-pointer transition ${selectedPrompt?.id === prompt.id ? 'bg-blue-50 border-blue-200 border' : 'hover:bg-gray-50 border border-transparent'}`}
                        >
                            <h3 className="font-medium text-gray-900">{prompt.name}</h3>
                            <p className="text-sm text-gray-500 truncate">{prompt.description}</p>
                        </div>
                    ))}
                </div>
            </div>

            {/* Main Content */}
            <div className="w-2/3 bg-white shadow rounded-lg flex flex-col">
                {selectedPrompt ? (
                    <div className="flex flex-col h-full">
                        <div className="p-4 border-b border-gray-200">
                            <h2 className="text-xl font-bold">{selectedPrompt.name}</h2>
                            <p className="text-gray-500">{selectedPrompt.description}</p>
                        </div>

                        {/* Version Creator */}
                        <div className="p-4 bg-gray-50 border-b border-gray-200">
                            <h3 className="text-sm font-medium text-gray-700 mb-2">Draft New Version</h3>
                            <textarea
                                className="w-full p-2 border border-gray-300 rounded shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                rows="3"
                                placeholder="Enter prompt text..."
                                value={newVersionText}
                                onChange={e => setNewVersionText(e.target.value)}
                            />
                            <div className="mt-2 flex justify-end">
                                <button onClick={handleCreateVersion} className="px-4 py-2 bg-blue-600 text-white rounded text-sm hover:bg-blue-700">Save Version</button>
                            </div>
                        </div>

                        {/* Version History */}
                        <div className="p-2 flex justify-end">
                            <button
                                onClick={() => setShowDiff(!showDiff)}
                                className={`flex items-center px-3 py-1 text-sm rounded border ${showDiff ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-white border-gray-300 text-gray-700'}`}
                            >
                                <GitCompare size={14} className="mr-1" />
                                {showDiff ? 'Hide Diff' : 'Compare with Previous'}
                            </button>
                        </div>
                        <div className="flex-1 overflow-y-auto p-4 space-y-6">
                            {versions.map((version, index) => ( // Added index
                                <div key={version.id} className="border border-gray-200 rounded-lg p-4">
                                    <div className="flex justify-between items-start mb-2">
                                        <div>
                                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                                v{version.version_number}
                                            </span>
                                            <span className={`ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                                                ${version.status === 'Approved' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                                                {version.status}
                                            </span>
                                        </div>
                                        <button
                                            onClick={() => handleGenerate(version.id)}
                                            className="flex items-center text-sm text-blue-600 hover:text-blue-800"
                                        >
                                            <Play size={16} className="mr-1" /> Run
                                        </button>
                                    </div>
                                    <div className="bg-gray-50 p-3 rounded text-sm font-mono text-gray-800 whitespace-pre-wrap">
                                        {showDiff && versions[index + 1] ? (
                                            <div>
                                                {Diff.diffWords(versions[index + 1].text, version.text).map((part, i) => (
                                                    <span key={i} className={part.added ? "bg-green-100 text-green-800" : part.removed ? "bg-red-100 text-red-800 line-through" : ""}>
                                                        {part.value}
                                                    </span>
                                                ))}
                                            </div>
                                        ) : (
                                            version.text
                                        )}
                                    </div>
                                    <div className="mt-2 text-xs text-gray-400">
                                        Created at {new Date(version.created_at).toLocaleString()}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                ) : (
                    <div className="flex items-center justify-center h-full text-gray-400">
                        Select a prompt to view details
                    </div>
                )}
            </div>

            {/* New Prompt Modal */}
            {showNewPromptModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
                    <div className="bg-white rounded-lg max-w-md w-full p-6">
                        <h3 className="text-lg font-bold mb-4">Create New Prompt</h3>
                        <input
                            type="text"
                            placeholder="Prompt Name"
                            className="w-full mb-3 p-2 border rounded"
                            value={newPromptName}
                            onChange={e => setNewPromptName(e.target.value)}
                        />
                        <textarea
                            placeholder="Description"
                            className="w-full mb-4 p-2 border rounded"
                            rows="2"
                            value={newPromptDesc}
                            onChange={e => setNewPromptDesc(e.target.value)}
                        />
                        <div className="flex justify-end gap-2">
                            <button onClick={() => setShowNewPromptModal(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded">Cancel</button>
                            <button onClick={handleCreatePrompt} className="px-4 py-2 bg-blue-600 text-white rounded">Create</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default PromptManager;
