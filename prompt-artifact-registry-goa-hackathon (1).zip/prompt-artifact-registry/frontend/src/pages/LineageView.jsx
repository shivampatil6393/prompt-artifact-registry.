import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../api';
import { ArrowDown, GitCommit, FileText, Bot } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const LineageView = () => {
    const { artifactId } = useParams();
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        api.get(`/lineage/${artifactId}`)
            .then(res => setData(res.data))
            .catch(err => console.error(err))
            .finally(() => setLoading(false));
    }, [artifactId]);

    if (loading) return <div>Loading lineage...</div>;
    if (!data) return <div>Lineage not found</div>;

    const { artifact, prompt_version, prompt } = data;

    return (
        <div className="max-w-3xl mx-auto space-y-8 py-8">
            <h1 className="text-2xl font-bold mb-8">Lineage Trace: Artifact #{artifact.id}</h1>

            <div className="relative border-l-2 border-gray-200 ml-6 space-y-12 pb-4">
                {/* Prompt Node */}
                <div className="relative pl-8">
                    <span className="absolute -left-3 top-0 bg-white border-2 border-blue-500 rounded-full p-1">
                        <FileText size={16} className="text-blue-500" />
                    </span>
                    <div className="bg-white p-4 rounded shadow border border-gray-200">
                        <h3 className="font-bold text-lg">Prompt: {prompt.name}</h3>
                        <p className="text-gray-600 text-sm mt-1">{prompt.description}</p>
                    </div>
                </div>

                {/* Prompt Version Node */}
                <div className="relative pl-8">
                    <span className="absolute -left-3 top-0 bg-white border-2 border-indigo-500 rounded-full p-1">
                        <GitCommit size={16} className="text-indigo-500" />
                    </span>
                    <div className="bg-white p-4 rounded shadow border border-gray-200">
                        <h3 className="font-bold text-lg">Version {prompt_version.version_number}</h3>
                        <pre className="mt-2 bg-gray-50 p-2 rounded text-sm whitespace-pre-wrap font-mono">
                            {prompt_version.text}
                        </pre>
                        <div className="mt-2 flex gap-2">
                            <span className={`px-2 py-0.5 rounded-full text-xs font-medium 
                                ${prompt_version.status === 'Approved' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                                {prompt_version.status}
                            </span>
                        </div>
                    </div>
                </div>

                {/* Model Execution Node (Implicit) */}
                <div className="relative pl-8">
                    <span className="absolute -left-3 top-0 bg-white border-2 border-purple-500 rounded-full p-1">
                        <Bot size={16} className="text-purple-500" />
                    </span>
                    <div className="bg-white p-3 rounded border border-dashed border-gray-300 transform scale-95 opacity-75">
                        <p className="text-sm font-medium text-gray-500">LLM Execution</p>
                        <div className="grid grid-cols-2 gap-x-4 gap-y-1 mt-1">
                            {Object.entries(JSON.parse(artifact.metadata_json || '{}')).map(([key, value]) => (
                                <div key={key} className="text-xs">
                                    <span className="text-gray-400 capitalize">{key.replace(/_/g, ' ')}:</span>
                                    <span className="text-gray-600 ml-1 font-mono">{typeof value === 'object' ? JSON.stringify(value) : value}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Artifact Node */}
                <div className="relative pl-8">
                    <span className="absolute -left-3 top-0 bg-white border-2 border-green-500 rounded-full p-1">
                        <ArrowDown size={16} className="text-green-500" />
                    </span>
                    <div className="bg-white p-4 rounded shadow-lg border border-green-200">
                        <div className="flex justify-between items-start">
                            <h3 className="font-bold text-lg">Artifact #{artifact.id}</h3>
                            <span className={`px-2 py-0.5 rounded-full text-xs font-medium 
                                ${artifact.status === 'Approved' ? 'bg-green-100 text-green-800' :
                                    artifact.status === 'Rejected' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}`}>
                                {artifact.status}
                            </span>
                        </div>
                        <div className="mt-2 bg-gray-900 text-green-400 p-4 rounded font-mono text-sm">
                            <ReactMarkdown>{artifact.content}</ReactMarkdown>
                        </div>
                        <div className="mt-2 text-xs text-gray-500">
                            Generated at: {new Date(artifact.created_at).toLocaleString()}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LineageView;
