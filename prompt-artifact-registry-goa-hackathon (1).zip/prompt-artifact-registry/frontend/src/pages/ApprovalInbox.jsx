import React, { useState, useEffect } from 'react';
import api from '../api';
import { Check, X, MessageSquare } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const ApprovalInbox = () => {
    const [artifacts, setArtifacts] = useState([]);
    const [user, setUser] = useState(null);

    useEffect(() => {
        const u = JSON.parse(localStorage.getItem('user'));
        setUser(u);
        fetchArtifacts();
    }, []);

    const fetchArtifacts = async () => {
        try {
            const res = await api.get('/artifacts/');
            // Filter: If Reviewer, see Pending Review. If Approver, maybe same?
            // For MVP all "Pending Review" items are in inbox.
            const pending = res.data.filter(a => a.status === 'Pending Review');
            setArtifacts(pending);
        } catch (err) {
            console.error(err);
        }
    };

    const handleAction = async (artifactId, action) => {
        const comment = prompt(`Enter comment for ${action}:`);
        try {
            await api.post(`/artifacts/${artifactId}/approve`, { action, comment });
            fetchArtifacts(); // Refresh list
        } catch (err) {
            alert("Action failed");
        }
    };

    if (!user) return <div>Please login</div>;
    const canReview = user.role === 'Reviewer' || user.role === 'Approver' || user.role === 'Admin';

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-900">Approval Inbox</h1>
            {!canReview && (
                <div className="bg-yellow-50 border-1 border-yellow-200 p-4 rounded text-yellow-800">
                    Your current role ({user.role}) does not have approval permissions.
                </div>
            )}

            <div className="grid gap-6">
                {artifacts.map(artifact => (
                    <div key={artifact.id} className="bg-white shadow rounded-lg p-6 flex flex-col sm:flex-row gap-6">
                        <div className="flex-1">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="font-bold text-lg">Artifact #{artifact.id}</h3>
                                <span className="text-sm text-gray-500">{new Date(artifact.created_at).toLocaleString()}</span>
                            </div>
                            <div className="bg-gray-50 p-4 rounded border border-gray-200 text-sm font-mono mb-4">
                                <ReactMarkdown>{artifact.content}</ReactMarkdown>
                            </div>
                            <div className="text-xs text-gray-500">
                                Prompt Version: {artifact.prompt_version_id} | Model: {JSON.parse(artifact.metadata_json || '{}').model}
                            </div>
                        </div>

                        {canReview && (
                            <div className="flex sm:flex-col gap-3 justify-center border-t sm:border-t-0 sm:border-l border-gray-100 pt-4 sm:pt-0 sm:pl-6">
                                <button
                                    onClick={() => handleAction(artifact.id, 'Approve')}
                                    className="flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 w-full"
                                >
                                    <Check size={16} className="mr-2" /> Approve
                                </button>
                                <button
                                    onClick={() => handleAction(artifact.id, 'Reject')}
                                    className="flex items-center justify-center px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 w-full"
                                >
                                    <X size={16} className="mr-2" /> Reject
                                </button>
                            </div>
                        )}
                    </div>
                ))}
                {artifacts.length === 0 && (
                    <div className="text-center py-12 text-gray-500 bg-white rounded-lg shadow">
                        <Check className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                        <h3 className="text-lg font-medium">All caught up!</h3>
                        <p>No artifacts pending review.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ApprovalInbox;
