import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import PromptManager from './pages/PromptManager';
import ArtifactRegistry from './pages/ArtifactRegistry';
import ApprovalInbox from './pages/ApprovalInbox';
import LineageView from './pages/LineageView';
import Layout from './components/Layout';

const ProtectedRoute = ({ children }) => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user) {
        return <Navigate to="/login" replace />;
    }
    return children;
};

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
                    <Route index element={<Dashboard />} />
                    <Route path="prompts" element={<PromptManager />} />
                    <Route path="artifacts" element={<ArtifactRegistry />} />
                    <Route path="lineage/:artifactId" element={<LineageView />} />
                    <Route path="approvals" element={<ApprovalInbox />} />
                </Route>
            </Routes>
        </Router>
    );
}

export default App;
